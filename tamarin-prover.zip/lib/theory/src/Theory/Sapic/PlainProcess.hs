module Theory.Sapic.PlainProcess

where

import Theory.Sapic.Process
import Theory.Sapic.Annotation

type PlainProcess = LProcess ProcessParsedAnnotation
