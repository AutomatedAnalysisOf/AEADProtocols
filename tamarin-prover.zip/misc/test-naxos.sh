#!/bin/sh

./averages.py --passes=1  "../examples/experiments/NAXOS*.spthy"
