TamarinAssist for Sublime Text 3
===

See the install notes contained in the [installation](https://tamarin-prover.github.io/manual/book/002_installation.html) chapter of the [manual](https://tamarin-prover.github.io/manual/).