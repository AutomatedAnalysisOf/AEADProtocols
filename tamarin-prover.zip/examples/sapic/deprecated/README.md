The following case studies make use of the accountability implementation of the now deprecated [SAPiC plugin](https://github.com/tamarin-prover/tamarin-prover/tree/be0214d5ea0516f1398744ec44590b5bdff2386a):

- (./accountability-old): See (./accountability-old/README.md).
- (./csf21-acc-unbounded): See (./csf21-acc-unbounded/README.md).
